library(shiny)
library(tidyverse)
library(lubridate)

ipf = read_csv("data/openipf-2021.csv")

# To filter out those event having at least 100 occurrences, and rank
# by the number of occurrences from top to bottom.
event_100_sorted <- function(ipf) {
    event_100_sorted <- ipf %>% 
        group_by(Event) %>% 
        summarize(freq = length(Event)) %>%
        arrange(desc(freq)) %>%
        filter(freq >= 100)
    return(event_100_sorted)
}

events <- event_100_sorted(ipf = ipf)

# the four frequent events are SBD, B, D, and BD.
events <- events[[1]]

# the months of 2021 (1,2,...,9,10)
months <- sort(unique(month(ipf$Date)))

# To filter out those athletes having sex be either male or female
# since there are so few sex that is "Mx".
sexs <- c("M", "F")

# Define UI for application that draws a histogram
ui <- fluidPage(
        navbarPage(title = "ipf 2021",
               tabPanel(title = "App",
                    # Application title
                    titlePanel("Powerlifing Data 2021"),
                        
                    # Sidebar
                    sidebarLayout(
                        sidebarPanel(
                            selectInput(
                                inputId = "events",
                                label = "Event:",
                                choices = events,
                                selected = "SBD"
                                ),
                            selectInput(
                                inputId = "months",
                                label = "Months:",
                                choices = months,
                                selected = "1"
                            ),
                            selectInput(
                                inputId = "sexs",
                                label = "Sex:",
                                choices = sexs,
                                selected = "M"
                            ),
                        ),
                        mainPanel(
                            plotOutput("plot"),
                            dataTableOutput("table")
                        )
                    )
               ),
               tabPanel(title = "About",
                        includeMarkdown("about.Rmd")
               )
        )
     )

# Define server logic required to draw a scatter plot
server <- function(input, output) {
    ipf_events <- reactive({
        ipf %>%
            select(Event, Date, Sex, Name, TotalKg) %>%
            filter(Event == input$events)
    })
    
    observeEvent(eventExpr = input$events,
                 handlerExpr = {
                     updateSelectInput(inputId = "months",
                                       choices = months)
                 }
    )
    
    ipf_months <- reactive({
        ipf_events() %>%
            filter(month(Date) == input$months) %>%
            select(Event, Date, Sex, Name, TotalKg) 
    })
    
    observeEvent(eventExpr = input$months,
                 handlerExpr = {
                     updateSelectInput(inputId = "sexs",
                                       choices = sexs)
                 }
    )
    
    ipf_sexs <- reactive({
        ipf_months() %>%
            filter(Sex == input$sexs) %>%
            select(Event, Date, Sex, Name, TotalKg) 
    })
    
    output$plot <- renderPlot({
        ggplot(data = ipf_sexs(), aes(x = day(Date),
                                        y = TotalKg)) +
        geom_point() + labs(title = 
"Total Kilograms Lifted by respective athletes 
that competed on given days of the month",
                            x = "day of the month",
                            y = "Total Kgs Lifted") +
            theme_bw() + scale_x_continuous(breaks = seq(1,31,4)) +
            theme(plot.title = element_text(hjust = 0.5))
    })
    
    output$table <- renderDataTable({
        ipf_sexs()
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
