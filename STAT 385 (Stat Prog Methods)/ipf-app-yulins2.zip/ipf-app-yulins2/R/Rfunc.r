# To filter out those event having at least 100 occurrences, and rank
# by the number of occurrences from top to bottom.
event_100_sorted <- function(ipf) {
  event_100_sorted <- ipf %>% 
                      group_by(Event) %>% 
                      summarize(freq = length(Event)) %>%
                      arrange(desc(freq)) %>%
                      filter(freq >= 100)
  return(event_100_sorted)
}